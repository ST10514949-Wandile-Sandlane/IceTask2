

package com.mycompany.icetask2;

import java.util.Scanner;


public class IceTask2 {

    public static void main(String[] args) {
        Scanner name = new Scanner(System.in);
        System.out.println("Enter your name :");
        String Name = name.next();
        System.out.println("Enter your surname :");
        String Surname = name.next();
        System.out.println(" Enter your Age :");
        int age = name.nextInt();
        boolean check = CheckIdentity(Name,Surname,age);
        if(check==true){
            System.out.println("It is Jack");
        }else {
            System.out.println("This is not Jack");}
        
             
    }
    public static boolean CheckIdentity(String Name,String Surname, int age) 
    {
       if(Name.equalsIgnoreCase("Jack")&&Surname.equalsIgnoreCase("Khoza")&& age==25){
       return true;
       }
       else{
       return false;
   }
}
}
